import React from 'react';
import { User as UserIcon } from 'lucide-react';
import Card from '../common/Card';
import { User } from '../../types';
import AttendanceTable from '../attendance/AttendanceTable';

interface UserProfileProps {
  user: User;
}

const UserProfile: React.FC<UserProfileProps> = ({ user }) => {
  return (
    <div className="space-y-6">
      <Card>
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
          {/* User avatar */}
          <div className="flex-shrink-0">
            {user.profileImage ? (
              <img 
                src={user.profileImage} 
                alt={user.name} 
                className="w-24 h-24 rounded-full object-cover border-4 border-white dark:border-slate-700 shadow-md"
              />
            ) : (
              <div className="w-24 h-24 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400 border-4 border-white dark:border-slate-700 shadow-md">
                <UserIcon size={36} />
              </div>
            )}
          </div>
          
          {/* User information */}
          <div className="flex-grow text-center sm:text-left">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">{user.name}</h2>
            <p className="text-slate-500 dark:text-slate-400">{user.email}</p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
              <div>
                <p className="text-sm text-slate-500 dark:text-slate-400">Department</p>
                <p className="font-medium text-slate-900 dark:text-slate-100">{user.department}</p>
              </div>
              
              <div>
                <p className="text-sm text-slate-500 dark:text-slate-400">Role</p>
                <p className="font-medium text-slate-900 dark:text-slate-100 capitalize">{user.role}</p>
              </div>
              
              <div>
                <p className="text-sm text-slate-500 dark:text-slate-400">Employee ID</p>
                <p className="font-medium text-slate-900 dark:text-slate-100">{user.id}</p>
              </div>
            </div>
          </div>
        </div>
      </Card>
      
      {/* User's attendance history */}
      <div>
        <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-4">Attendance History</h3>
        <AttendanceTable userId={user.id} />
      </div>
    </div>
  );
};

export default UserProfile;