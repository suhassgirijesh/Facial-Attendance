// User Types
export type UserRole = 'admin' | 'employee';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department: string;
  profileImage?: string;
}

// Attendance Types
export interface AttendanceRecord {
  id: string;
  userId: string;
  userName: string;
  timestamp: string;
  status: 'present' | 'absent' | 'late';
  department: string;
}

// Theme Type
export type Theme = 'light' | 'dark';