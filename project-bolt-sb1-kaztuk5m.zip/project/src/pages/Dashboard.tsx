import React from 'react';
import { Users, Clock, Calendar, UserCheck } from 'lucide-react';
import Card from '../components/common/Card';
import PageLayout from '../components/layout/PageLayout';
import { useAuth } from '../context/AuthContext';
import AttendanceTable from '../components/attendance/AttendanceTable';
import { Link } from 'react-router-dom';

const Dashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';
  
  // Stats cards data
  const stats = [
    {
      title: 'Total Employees',
      value: isAdmin ? '28' : '-',
      icon: Users,
      color: 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400',
      link: isAdmin ? '/users' : undefined,
    },
    {
      title: 'Present Today',
      value: isAdmin ? '22' : '-',
      icon: UserCheck,
      color: 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400',
      link: isAdmin ? '/reports' : undefined,
    },
    {
      title: 'Absent Today',
      value: isAdmin ? '6' : '-',
      icon: Calendar,
      color: 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400',
      link: isAdmin ? '/reports' : undefined,
    },
    {
      title: 'Current Time',
      value: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      icon: Clock,
      color: 'bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400',
    },
  ];
  
  return (
    <PageLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Dashboard</h1>
        <p className="text-slate-600 dark:text-slate-400">
          Welcome back, {currentUser?.name}
        </p>
      </div>
      
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow duration-200">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-1">{stat.title}</p>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white">{stat.value}</h3>
              </div>
              <div className={`rounded-full p-3 ${stat.color}`}>
                <stat.icon size={20} />
              </div>
            </div>
            {stat.link && (
              <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-700">
                <Link to={stat.link} className="text-sm text-blue-600 dark:text-blue-400 hover:underline">
                  View details
                </Link>
              </div>
            )}
          </Card>
        ))}
      </div>
      
      {/* Quick Actions */}
      <div className="mb-8">
        <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <Link to="/mark-attendance">
            <Card className="hover:shadow-lg transition-shadow duration-200 h-full">
              <div className="flex items-center">
                <div className="bg-blue-100 dark:bg-blue-900/30 rounded-full p-3 mr-4 text-blue-600 dark:text-blue-400">
                  <Camera size={24} />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 dark:text-white">Mark Attendance</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400">Use facial recognition to mark attendance</p>
                </div>
              </div>
            </Card>
          </Link>
          
          <Link to="/reports">
            <Card className="hover:shadow-lg transition-shadow duration-200 h-full">
              <div className="flex items-center">
                <div className="bg-purple-100 dark:bg-purple-900/30 rounded-full p-3 mr-4 text-purple-600 dark:text-purple-400">
                  <FileText size={24} />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 dark:text-white">View Reports</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400">Access attendance reports and analytics</p>
                </div>
              </div>
            </Card>
          </Link>
          
          {isAdmin && (
            <Link to="/users">
              <Card className="hover:shadow-lg transition-shadow duration-200 h-full">
                <div className="flex items-center">
                  <div className="bg-emerald-100 dark:bg-emerald-900/30 rounded-full p-3 mr-4 text-emerald-600 dark:text-emerald-400">
                    <UserPlus size={24} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 dark:text-white">Register User</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Add new users to the system</p>
                  </div>
                </div>
              </Card>
            </Link>
          )}
        </div>
      </div>
      
      {/* Recent Attendance */}
      <div>
        <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-4">Recent Attendance</h2>
        <AttendanceTable userId={isAdmin ? undefined : currentUser?.id} />
      </div>
    </PageLayout>
  );
};

// Missing imports will cause an error - add them
import { UserPlus, FileText, Camera } from 'lucide-react';

export default Dashboard;