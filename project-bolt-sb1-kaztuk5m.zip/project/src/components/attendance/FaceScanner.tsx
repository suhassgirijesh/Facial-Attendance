import React, { useState, useRef, useEffect } from 'react';
import { Camera, CheckCircle } from 'lucide-react';
import Button from '../common/Button';
import Card from '../common/Card';
import { useAuth } from '../../context/AuthContext';

const FaceScanner: React.FC = () => {
  const { currentUser } = useAuth();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scanComplete, setScanComplete] = useState(false);
  const [scanMessage, setScanMessage] = useState('');
  const [showOverlay, setShowOverlay] = useState(false);

  // Mock the face scanning process
  const startScan = async () => {
    setIsScanning(true);
    setScanComplete(false);
    setShowOverlay(false);
    
    try {
      // Get webcam access 
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        
        // Simulate scanning process
        setTimeout(() => {
          setShowOverlay(true);
          
          // Simulate scan completion after 2 seconds
          setTimeout(() => {
            // Take snapshot for confirmation
            if (canvasRef.current && videoRef.current) {
              const context = canvasRef.current.getContext('2d');
              canvasRef.current.width = videoRef.current.videoWidth;
              canvasRef.current.height = videoRef.current.videoHeight;
              context?.drawImage(videoRef.current, 0, 0);
            }
            
            // Simulate successful scan
            setScanComplete(true);
            setIsScanning(false);
            setScanMessage(`Attendance marked for ${currentUser?.name}`);
            
            // Stop all video streams
            if (videoRef.current && videoRef.current.srcObject) {
              const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
              tracks.forEach(track => track.stop());
              videoRef.current.srcObject = null;
            }
          }, 2000);
        }, 1500);
      } else {
        setScanMessage('Camera access not supported in this browser.');
        setIsScanning(false);
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
      setScanMessage('Error accessing camera. Please check permissions.');
      setIsScanning(false);
    }
  };

  // Stop all video streams when component unmounts
  useEffect(() => {
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach(track => track.stop());
      }
    };
  }, []);

  // Reset scan when user changes
  useEffect(() => {
    setScanComplete(false);
    setScanMessage('');
  }, [currentUser]);

  const handleResetScan = () => {
    setScanComplete(false);
    setScanMessage('');
  };

  return (
    <Card className="max-w-lg mx-auto">
      <div className="flex flex-col items-center">
        <h2 className="text-xl font-semibold mb-4 text-center">Face Recognition Attendance</h2>
        
        <div className="relative w-full bg-slate-100 dark:bg-slate-700 rounded-lg overflow-hidden aspect-video mb-4">
          {!scanComplete ? (
            <>
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                className={`w-full h-full object-cover ${isScanning ? 'block' : 'hidden'}`}
              />
              
              {!isScanning && (
                <div className="absolute inset-0 flex items-center justify-center bg-slate-200 dark:bg-slate-700">
                  <Camera size={64} className="text-slate-400 dark:text-slate-500" />
                </div>
              )}
              
              {showOverlay && (
                <div className="absolute inset-0 border-4 border-blue-500 animate-pulse flex items-center justify-center">
                  <div className="text-center bg-blue-500/70 rounded-lg p-3 text-white font-bold">
                    Scanning Face...
                  </div>
                </div>
              )}
            </>
          ) : (
            <>
              <canvas 
                ref={canvasRef} 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-emerald-500/20 border-4 border-emerald-500 flex items-center justify-center">
                <div className="bg-white dark:bg-slate-800 rounded-lg p-4 shadow-lg text-center">
                  <CheckCircle size={48} className="text-emerald-500 mx-auto mb-2" />
                  <p className="font-bold text-slate-900 dark:text-white">Attendance Marked!</p>
                  <p className="text-sm text-slate-600 dark:text-slate-300">
                    {new Date().toLocaleString()}
                  </p>
                </div>
              </div>
            </>
          )}
        </div>
        
        {scanMessage && (
          <div className={`text-center p-2 w-full rounded-md mb-4 ${
            scanComplete ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-300' : 
            'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300'
          }`}>
            {scanMessage}
          </div>
        )}
        
        <div className="flex space-x-4">
          {!scanComplete ? (
            <Button 
              onClick={startScan} 
              disabled={isScanning}
              isLoading={isScanning}
              className="w-full"
            >
              <Camera size={20} className="mr-2" />
              {isScanning ? 'Scanning...' : 'Start Face Scan'}
            </Button>
          ) : (
            <Button 
              onClick={handleResetScan}
              variant="secondary"
              className="w-full"
            >
              Scan Again
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
};

export default FaceScanner;