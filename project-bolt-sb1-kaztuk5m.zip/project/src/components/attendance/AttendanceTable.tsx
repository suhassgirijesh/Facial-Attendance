import React, { useState } from 'react';
import { Calendar, Search, Download, Filter } from 'lucide-react';
import Card from '../common/Card';
import Button from '../common/Button';
import { AttendanceRecord } from '../../types';

// Mock attendance data
const MOCK_ATTENDANCE: AttendanceRecord[] = [
  { 
    id: '1', 
    userId: '1', 
    userName: 'Admin User', 
    timestamp: '2025-05-01T08:30:00Z', 
    status: 'present',
    department: 'IT'
  },
  { 
    id: '2', 
    userId: '2', 
    userName: 'John Employee', 
    timestamp: '2025-05-01T08:45:00Z', 
    status: 'present',
    department: 'Marketing'
  },
  { 
    id: '3', 
    userId: '2', 
    userName: 'John Employee', 
    timestamp: '2025-05-02T08:35:00Z', 
    status: 'present',
    department: 'Marketing'
  },
  { 
    id: '4', 
    userId: '1', 
    userName: 'Admin User', 
    timestamp: '2025-05-02T09:10:00Z', 
    status: 'late',
    department: 'IT'
  },
  { 
    id: '5', 
    userId: '2', 
    userName: 'John Employee', 
    timestamp: '2025-05-03T08:30:00Z', 
    status: 'absent',
    department: 'Marketing'
  },
];

interface AttendanceTableProps {
  userId?: string; // If provided, filters for specific user
}

const AttendanceTable: React.FC<AttendanceTableProps> = ({ userId }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  
  // Filter attendance records
  const filteredRecords = MOCK_ATTENDANCE.filter(record => {
    // Filter by user if userId is provided
    if (userId && record.userId !== userId) return false;
    
    // Search by name
    if (searchTerm && !record.userName.toLowerCase().includes(searchTerm.toLowerCase())) return false;
    
    // Filter by date
    if (dateFilter && !record.timestamp.includes(dateFilter)) return false;
    
    // Filter by status
    if (statusFilter && record.status !== statusFilter) return false;
    
    return true;
  });

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  const handleExportCSV = () => {
    // In a real app, this would generate and download a CSV
    alert('Export functionality would be implemented here');
  };

  return (
    <Card className="w-full">
      <div className="mb-4">
        <h2 className="text-xl font-semibold mb-4">Attendance Records</h2>
        
        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-3 mb-4">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={18} />
            <input
              type="text"
              placeholder="Search by name"
              className="pl-10 pr-4 py-2 w-full border border-slate-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:ring-blue-500 focus:border-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={18} />
            <input
              type="date"
              className="pl-10 pr-4 py-2 border border-slate-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:ring-blue-500 focus:border-blue-500"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
            />
          </div>
          
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={18} />
            <select
              className="pl-10 pr-4 py-2 border border-slate-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:ring-blue-500 focus:border-blue-500"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="">All Statuses</option>
              <option value="present">Present</option>
              <option value="absent">Absent</option>
              <option value="late">Late</option>
            </select>
          </div>
          
          <Button variant="secondary" onClick={handleExportCSV}>
            <Download size={18} className="mr-2" />
            Export
          </Button>
        </div>
      </div>
      
      {/* Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
          <thead className="bg-slate-50 dark:bg-slate-800">
            <tr>
              {!userId && <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Employee</th>}
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Date & Time</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Status</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Department</th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
            {filteredRecords.map((record) => (
              <tr key={record.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                {!userId && (
                  <td className="px-4 py-3 whitespace-nowrap">
                    <div className="text-sm font-medium text-slate-900 dark:text-white">{record.userName}</div>
                  </td>
                )}
                <td className="px-4 py-3 whitespace-nowrap">
                  <div className="text-sm text-slate-700 dark:text-slate-300">{formatDate(record.timestamp)}</div>
                </td>
                <td className="px-4 py-3 whitespace-nowrap">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    record.status === 'present' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' :
                    record.status === 'late' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300' :
                    'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                  }`}>
                    {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                  </span>
                </td>
                <td className="px-4 py-3 whitespace-nowrap">
                  <div className="text-sm text-slate-700 dark:text-slate-300">{record.department}</div>
                </td>
              </tr>
            ))}
            
            {filteredRecords.length === 0 && (
              <tr>
                <td colSpan={userId ? 3 : 4} className="px-4 py-8 text-center text-sm text-slate-500 dark:text-slate-400">
                  No attendance records found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </Card>
  );
};

export default AttendanceTable;