import React, { useState } from 'react';
import { Save, Moon, Sun, Bell, Lock } from 'lucide-react';
import PageLayout from '../components/layout/PageLayout';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import { useTheme } from '../context/ThemeContext';

const Settings: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const [notifications, setNotifications] = useState({
    emailAlerts: true,
    attendanceConfirmation: true,
    systemUpdates: false,
  });
  const [security, setSecurity] = useState({
    twoFactorAuth: false,
    sessionTimeout: '30',
  });
  
  const handleNotificationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setNotifications(prev => ({ ...prev, [name]: checked }));
  };
  
  const handleSecurityChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const newValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    setSecurity(prev => ({ ...prev, [name]: newValue }));
  };
  
  const handleSaveSettings = () => {
    // In a real app, this would save settings to a server
    console.log('Saving settings:', { notifications, security });
    alert('Settings saved successfully!');
  };
  
  return (
    <PageLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Settings</h1>
        <p className="text-slate-600 dark:text-slate-400">
          Customize your experience and set your preferences
        </p>
      </div>
      
      <div className="space-y-6">
        {/* Appearance */}
        <Card className="overflow-visible">
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-4 flex items-center">
            <Sun className="mr-2 text-amber-500" size={20} />
            <Moon className="mr-2 text-indigo-500" size={20} />
            Appearance
          </h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium text-slate-900 dark:text-white">Theme Mode</h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Choose between light and dark theme
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-slate-600 dark:text-slate-400">Light</span>
                <button
                  type="button"
                  onClick={toggleTheme}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                    theme === 'dark' ? 'bg-blue-600' : 'bg-slate-200 dark:bg-slate-700'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      theme === 'dark' ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
                <span className="text-sm text-slate-600 dark:text-slate-400">Dark</span>
              </div>
            </div>
          </div>
        </Card>
        
        {/* Notifications */}
        <Card className="overflow-visible">
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-4 flex items-center">
            <Bell className="mr-2 text-blue-500" size={20} />
            Notifications
          </h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium text-slate-900 dark:text-white">Email Alerts</h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Receive email notifications for important events
                </p>
              </div>
              <div>
                <input
                  type="checkbox"
                  id="emailAlerts"
                  name="emailAlerts"
                  checked={notifications.emailAlerts}
                  onChange={handleNotificationChange}
                  className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium text-slate-900 dark:text-white">Attendance Confirmation</h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Receive confirmation when attendance is successfully marked
                </p>
              </div>
              <div>
                <input
                  type="checkbox"
                  id="attendanceConfirmation"
                  name="attendanceConfirmation"
                  checked={notifications.attendanceConfirmation}
                  onChange={handleNotificationChange}
                  className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium text-slate-900 dark:text-white">System Updates</h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Get notified about new features and system updates
                </p>
              </div>
              <div>
                <input
                  type="checkbox"
                  id="systemUpdates"
                  name="systemUpdates"
                  checked={notifications.systemUpdates}
                  onChange={handleNotificationChange}
                  className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>
        </Card>
        
        {/* Security */}
        <Card className="overflow-visible">
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-4 flex items-center">
            <Lock className="mr-2 text-emerald-500" size={20} />
            Security
          </h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium text-slate-900 dark:text-white">Two-Factor Authentication</h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Add an extra layer of security to your account
                </p>
              </div>
              <div>
                <input
                  type="checkbox"
                  id="twoFactorAuth"
                  name="twoFactorAuth"
                  checked={security.twoFactorAuth}
                  onChange={handleSecurityChange}
                  className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
              </div>
            </div>
            
            <div>
              <h3 className="font-medium text-slate-900 dark:text-white mb-1">Session Timeout</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
                Automatically log out after a period of inactivity
              </p>
              <select
                id="sessionTimeout"
                name="sessionTimeout"
                value={security.sessionTimeout}
                onChange={handleSecurityChange}
                className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="15">15 minutes</option>
                <option value="30">30 minutes</option>
                <option value="60">1 hour</option>
                <option value="120">2 hours</option>
                <option value="never">Never</option>
              </select>
            </div>
          </div>
        </Card>
        
        {/* Save Button */}
        <div className="flex justify-end">
          <Button onClick={handleSaveSettings}>
            <Save size={20} className="mr-2" />
            Save Settings
          </Button>
        </div>
      </div>
    </PageLayout>
  );
};

export default Settings;