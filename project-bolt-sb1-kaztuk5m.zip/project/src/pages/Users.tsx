import React, { useState } from 'react';
import PageLayout from '../components/layout/PageLayout';
import UserRegistration from '../components/users/UserRegistration';
import UserProfile from '../components/users/UserProfile';
import { User } from '../types';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import { UserRound, Plus, Search } from 'lucide-react';

// Mock users data
const MOCK_USERS: User[] = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@example.com',
    role: 'admin',
    department: 'IT',
    profileImage: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: '2',
    name: 'John Employee',
    email: 'john@example.com',
    role: 'employee',
    department: 'Marketing',
    profileImage: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: '3',
    name: 'Sarah Jones',
    email: 'sarah@example.com',
    role: 'employee',
    department: 'Finance',
    profileImage: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: '4',
    name: 'Michael Brown',
    email: 'michael@example.com',
    role: 'employee',
    department: 'Sales',
    profileImage: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=400'
  }
];

const Users: React.FC = () => {
  const [showRegistration, setShowRegistration] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Filter users based on search term
  const filteredUsers = MOCK_USERS.filter(user => 
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.department.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  return (
    <PageLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Users Management</h1>
        <p className="text-slate-600 dark:text-slate-400">
          Manage users and their access to the facial recognition system
        </p>
      </div>
      
      {showRegistration ? (
        <div>
          <div className="mb-4">
            <Button 
              variant="secondary" 
              onClick={() => setShowRegistration(false)}
            >
              Back to Users List
            </Button>
          </div>
          <UserRegistration />
        </div>
      ) : selectedUser ? (
        <div>
          <div className="mb-4">
            <Button 
              variant="secondary" 
              onClick={() => setSelectedUser(null)}
            >
              Back to Users List
            </Button>
          </div>
          <UserProfile user={selectedUser} />
        </div>
      ) : (
        <div>
          <div className="mb-6 flex flex-col sm:flex-row justify-between gap-4">
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={18} />
              <input
                type="text"
                placeholder="Search users by name, email, or department"
                className="pl-10 pr-4 py-2 w-full border border-slate-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:ring-blue-500 focus:border-blue-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button onClick={() => setShowRegistration(true)}>
              <Plus size={20} className="mr-2" />
              Add New User
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredUsers.map(user => (
              <Card 
                key={user.id} 
                className="hover:shadow-lg transition-shadow duration-200 cursor-pointer"
                onClick={() => setSelectedUser(user)}
              >
                <div className="flex items-center space-x-4">
                  {user.profileImage ? (
                    <img 
                      src={user.profileImage} 
                      alt={user.name} 
                      className="w-16 h-16 rounded-full object-cover"
                    />
                  ) : (
                    <div className="w-16 h-16 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400">
                      <UserRound size={32} />
                    </div>
                  )}
                  
                  <div>
                    <h3 className="font-semibold text-slate-900 dark:text-white">{user.name}</h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400">{user.email}</p>
                    <div className="flex items-center mt-1">
                      <span className="text-xs bg-slate-100 dark:bg-slate-700 px-2 py-0.5 rounded text-slate-600 dark:text-slate-300 mr-2">
                        {user.department}
                      </span>
                      <span className={`text-xs px-2 py-0.5 rounded ${
                        user.role === 'admin' 
                          ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300' 
                          : 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300'
                      }`}>
                        {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                      </span>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
            
            {filteredUsers.length === 0 && (
              <div className="col-span-full py-8 text-center text-slate-500 dark:text-slate-400">
                No users found matching your search criteria
              </div>
            )}
          </div>
        </div>
      )}
    </PageLayout>
  );
};

export default Users;