import React from 'react';
import PageLayout from '../components/layout/PageLayout';
import AttendanceTable from '../components/attendance/AttendanceTable';

const Reports: React.FC = () => {
  return (
    <PageLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Attendance Reports</h1>
        <p className="text-slate-600 dark:text-slate-400">
          View and analyze attendance data across your organization
        </p>
      </div>
      
      <AttendanceTable />
    </PageLayout>
  );
};

export default Reports;