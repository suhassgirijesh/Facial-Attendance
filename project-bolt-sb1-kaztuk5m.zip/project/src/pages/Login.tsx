import React from 'react';
import { Navigate } from 'react-router-dom';
import LoginForm from '../components/auth/LoginForm';
import { useAuth } from '../context/AuthContext';

const Login: React.FC = () => {
  const { isAuthenticated } = useAuth();
  
  // Redirect to dashboard if already logged in
  if (isAuthenticated) {
    return <Navigate to="/dashboard" />;
  }
  
  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-900 py-12 flex items-center justify-center">
      <div className="container mx-auto px-4 max-w-md">
        <LoginForm />
      </div>
    </div>
  );
};

export default Login;