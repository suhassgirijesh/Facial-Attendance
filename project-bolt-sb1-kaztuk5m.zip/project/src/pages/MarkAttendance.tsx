import React from 'react';
import PageLayout from '../components/layout/PageLayout';
import FaceScanner from '../components/attendance/FaceScanner';

const MarkAttendance: React.FC = () => {
  return (
    <PageLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Mark Attendance</h1>
        <p className="text-slate-600 dark:text-slate-400">
          Use the camera to scan your face and mark your attendance
        </p>
      </div>
      
      <FaceScanner />
    </PageLayout>
  );
};

export default MarkAttendance;