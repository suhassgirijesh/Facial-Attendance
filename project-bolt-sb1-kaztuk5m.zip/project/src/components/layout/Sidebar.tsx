import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  FileText, 
  Camera, 
  Settings,
  Home
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface SidebarProps {
  isOpen: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen }) => {
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';
  
  // Common styles for nav links
  const linkClasses = "flex items-center px-4 py-3 text-gray-600 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-slate-800 rounded-md transition-colors";
  const activeLinkClasses = "bg-blue-50 dark:bg-slate-800 text-blue-600 dark:text-blue-400 font-medium";
  
  return (
    <aside className={`fixed inset-y-0 left-0 z-20 w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-700 transform ${
      isOpen ? 'translate-x-0' : '-translate-x-full'
    } transition-transform duration-200 ease-in-out pt-16 h-full overflow-y-auto`}>
      <div className="px-3 py-4">
        <div className="space-y-1">
          <NavLink
            to="/"
            className={({ isActive }) => 
              `${linkClasses} ${isActive ? activeLinkClasses : ''}`
            }
          >
            <Home className="mr-3 h-5 w-5" />
            Home
          </NavLink>

          <NavLink
            to="/dashboard"
            className={({ isActive }) => 
              `${linkClasses} ${isActive ? activeLinkClasses : ''}`
            }
          >
            <LayoutDashboard className="mr-3 h-5 w-5" />
            Dashboard
          </NavLink>

          <NavLink
            to="/mark-attendance"
            className={({ isActive }) => 
              `${linkClasses} ${isActive ? activeLinkClasses : ''}`
            }
          >
            <Camera className="mr-3 h-5 w-5" />
            Mark Attendance
          </NavLink>

          <NavLink
            to="/reports"
            className={({ isActive }) => 
              `${linkClasses} ${isActive ? activeLinkClasses : ''}`
            }
          >
            <FileText className="mr-3 h-5 w-5" />
            Reports
          </NavLink>

          {isAdmin && (
            <NavLink
              to="/users"
              className={({ isActive }) => 
                `${linkClasses} ${isActive ? activeLinkClasses : ''}`
              }
            >
              <Users className="mr-3 h-5 w-5" />
              Users
            </NavLink>
          )}

          <NavLink
            to="/settings"
            className={({ isActive }) => 
              `${linkClasses} ${isActive ? activeLinkClasses : ''}`
            }
          >
            <Settings className="mr-3 h-5 w-5" />
            Settings
          </NavLink>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;