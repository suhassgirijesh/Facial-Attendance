import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Camera, 
  Clock, 
  ShieldCheck, 
  BarChart, 
  UserRound, 
  ArrowRight 
} from 'lucide-react';
import Button from '../components/common/Button';
import FeatureCard from '../components/home/FeatureCard';
import HowItWorks from '../components/home/HowItWorks';
import { useAuth } from '../context/AuthContext';

const Home: React.FC = () => {
  const { isAuthenticated } = useAuth();
  
  const features = [
    {
      icon: Camera,
      title: 'Facial Recognition',
      description: 'Advanced AI technology accurately identifies individuals through facial features.'
    },
    {
      icon: Clock,
      title: 'Real-time Tracking',
      description: 'Mark attendance instantly with precise timestamps and location tracking.'
    },
    {
      icon: ShieldCheck,
      title: 'Secure & Reliable',
      description: 'Enterprise-grade security ensures data privacy and prevents spoofing attempts.'
    },
    {
      icon: BarChart,
      title: 'Detailed Analytics',
      description: 'Comprehensive reports and insights on attendance patterns and trends.'
    },
    {
      icon: UserRound,
      title: 'User Management',
      description: 'Easy administration of users, departments, and role-based permissions.'
    }
  ];

  return (
    <div className="space-y-16 -mt-16 pb-16">
      {/* Hero Section */}
      <section className="relative pt-20 pb-20 bg-gradient-to-br from-blue-600 to-indigo-800 text-white overflow-hidden">
        <div className="absolute inset-0 bg-pattern opacity-10"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="flex flex-col lg:flex-row items-center">
            <div className="lg:w-1/2 mb-10 lg:mb-0 text-center lg:text-left">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
                Face Recognition<br />Attendance System
              </h1>
              <p className="text-xl md:text-2xl text-blue-100 mb-8 max-w-xl mx-auto lg:mx-0">
                Automate attendance tracking with secure facial recognition technology. Fast, accurate, and contactless.
              </p>
              <div className="flex flex-col sm:flex-row justify-center lg:justify-start gap-4">
                {isAuthenticated ? (
                  <Link to="/dashboard">
                    <Button className="px-8 py-3 text-lg">
                      Go to Dashboard
                      <ArrowRight className="ml-2" size={20} />
                    </Button>
                  </Link>
                ) : (
                  <Link to="/login">
                    <Button className="px-8 py-3 text-lg">
                      Get Started
                      <ArrowRight className="ml-2" size={20} />
                    </Button>
                  </Link>
                )}
                <Link to="/mark-attendance">
                  <Button variant="secondary" className="px-8 py-3 text-lg">
                    Mark Attendance
                    <Camera className="ml-2" size={20} />
                  </Button>
                </Link>
              </div>
            </div>
            <div className="lg:w-1/2">
              <div className="relative mx-auto max-w-md">
                <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl overflow-hidden border-8 border-white dark:border-slate-700">
                  <div className="aspect-[4/3] bg-slate-100 dark:bg-slate-700 relative flex items-center justify-center">
                    <img 
                      src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                      alt="Face recognition in action" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-blue-600/20 flex flex-col items-center justify-center p-4">
                      <div className="bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm p-4 rounded-lg max-w-xs text-center">
                        <p className="text-slate-900 dark:text-white text-lg font-semibold">Face Detected</p>
                        <p className="text-blue-600 dark:text-blue-400 text-sm">Authentication successful</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="absolute -bottom-4 -right-4 bg-blue-100 dark:bg-blue-900/30 rounded-full p-4 text-blue-600 dark:text-blue-400 border-4 border-white dark:border-slate-700">
                  <CheckCircle size={32} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How it works section */}
      <HowItWorks />
      
      {/* Features Section */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">
              Key Features
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              Our system combines cutting-edge technology with user-friendly design to streamline attendance management
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <FeatureCard 
                key={index}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 dark:bg-blue-900 py-16 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Modernize Your Attendance System?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join thousands of organizations using our technology to simplify attendance tracking
          </p>
          <Link to={isAuthenticated ? "/dashboard" : "/login"}>
            <Button className="px-8 py-3 text-lg bg-white text-blue-600 hover:bg-blue-50">
              {isAuthenticated ? "Go to Dashboard" : "Get Started Now"}
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

// Missing imports will cause an error - add them
import { CheckCircle } from 'lucide-react';

export default Home;