import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Moon, Sun, LogOut } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';

interface NavbarProps {
  toggleSidebar: () => void;
  isSidebarOpen: boolean;
}

const Navbar: React.FC<NavbarProps> = ({ toggleSidebar, isSidebarOpen }) => {
  const { currentUser, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();

  // Get page title based on current route
  const getPageTitle = () => {
    const path = location.pathname;
    if (path === '/') return 'Home';
    if (path === '/dashboard') return 'Dashboard';
    if (path === '/mark-attendance') return 'Mark Attendance';
    if (path === '/reports') return 'Reports';
    if (path === '/users') return 'Users';
    if (path === '/settings') return 'Settings';
    if (path === '/login') return 'Login';
    return 'Facial Recognition Attendance';
  };

  return (
    <nav className="fixed top-0 z-30 w-full bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Left side - Logo and hamburger */}
          <div className="flex items-center">
            <button 
              onClick={toggleSidebar}
              className="p-2 rounded-md text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 focus:outline-none"
            >
              {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            
            <Link to="/" className="ml-2 sm:ml-4 flex items-center">
              <span className="font-bold text-xl text-blue-600 dark:text-blue-400">FaceAttend</span>
            </Link>
            
            <h1 className="hidden sm:block ml-4 text-lg font-medium text-slate-700 dark:text-white">
              {getPageTitle()}
            </h1>
          </div>

          {/* Right side - User info and actions */}
          <div className="flex items-center">
            {/* Theme toggle */}
            <button 
              onClick={toggleTheme} 
              className="p-2 rounded-md text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 focus:outline-none"
            >
              {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            
            {/* User info */}
            {currentUser && (
              <div className="flex items-center ml-4">
                <div className="hidden md:flex flex-col items-end mr-2">
                  <span className="text-sm font-medium text-slate-700 dark:text-white">
                    {currentUser.name}
                  </span>
                  <span className="text-xs text-slate-500 dark:text-slate-400">
                    {currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1)}
                  </span>
                </div>
                
                {currentUser.profileImage ? (
                  <img 
                    src={currentUser.profileImage} 
                    alt={currentUser.name} 
                    className="h-8 w-8 rounded-full object-cover border-2 border-white dark:border-slate-700"
                  />
                ) : (
                  <div className="h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center text-white">
                    {currentUser.name.charAt(0).toUpperCase()}
                  </div>
                )}
                
                <button 
                  onClick={logout}
                  className="ml-2 p-2 rounded-md text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 focus:outline-none"
                  title="Logout"
                >
                  <LogOut size={20} />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;