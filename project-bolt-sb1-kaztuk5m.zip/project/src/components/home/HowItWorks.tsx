import React from 'react';
import { Camera, CheckCircle, Clock, Database } from 'lucide-react';

const HowItWorks: React.FC = () => {
  const steps = [
    {
      icon: <Camera className="h-8 w-8 text-blue-600 dark:text-blue-400" />,
      title: 'Face Scan',
      description: 'Open the camera on your device and position your face in the frame for scanning.'
    },
    {
      icon: <Database className="h-8 w-8 text-blue-600 dark:text-blue-400" />,
      title: 'Detection',
      description: 'Our AI technology identifies and verifies your face against the database.'
    },
    {
      icon: <CheckCircle className="h-8 w-8 text-blue-600 dark:text-blue-400" />,
      title: 'Verification',
      description: 'Once verified, your identity is confirmed securely and accurately.'
    },
    {
      icon: <Clock className="h-8 w-8 text-blue-600 dark:text-blue-400" />,
      title: 'Attendance Marked',
      description: 'Your attendance is automatically recorded with precise timestamp.'
    }
  ];

  return (
    <section className="py-12 bg-slate-50 dark:bg-slate-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">How It Works</h2>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            Our facial recognition attendance system makes tracking attendance simple, secure, and efficient
          </p>
        </div>
        
        <div className="relative">
          {/* Connection line */}
          <div className="hidden md:block absolute top-1/2 left-0 right-0 h-1 bg-blue-200 dark:bg-blue-900/50 -translate-y-1/2 z-0"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
            {steps.map((step, index) => (
              <div key={index} className="flex flex-col items-center text-center">
                <div className="bg-white dark:bg-slate-800 rounded-full p-6 shadow-md mb-4 border-4 border-blue-100 dark:border-blue-900/50">
                  {step.icon}
                </div>
                <h3 className="text-xl font-semibold text-slate-900 dark:text-white mt-2 mb-1">{step.title}</h3>
                <p className="text-slate-600 dark:text-slate-400">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;